# OV7670 camera edge detector + original EN.520.424 VGA lab

This revision adapts the **actual `lab_f.vhd` VGA code** (MMCM parameters, 800×525 counters, registered HSYNC/VSYNC and blanking) to read pixels from the edge-detector framebuffer. `rtl/lab_vga.vhd` is the adapted VGA lab code; the camera/Sobel modules are retained.

**Wiring:** VGA Pmod as wired in your successful class lab; all 8 FPGA output signals use JA. The VGA Pmod must be the same 2-bit/channel hardware from the lab; other 12-bit Pmod VGA boards will need a different adapter/pin map. **Camera GPIOs:** D0..D7 DIP1..8, HREF 9, VSYNC 10, PCLK 18, XCLK 19, SCL 20, SDA 21; RESET is NOT mapped to DIP 11. Camera ground to DIP25. Use a regulated breakout-compatible power supply, not FPGA GPIO.

**Test:** Keep camera disconnected at first. Build design, connect VGA as in lab, and hold BTN0 for the checkerboard. If this works, connect camera and inspect the LED indicators.

The output is 640×480 VGA at 25.2 MHz; camera content is 320×240 scaled 2×. The display is monochrome, so red, green, blue 2-bit channels are each driven to 00 or 11.

**Caution:** The original SCCB configuration/camera clock and the camera-to-VGA frame buffer remain unverified on physical hardware. A working VGA test image alone does not prove the OV7670 is configured successfully. A camera with output needing 24 MHz XCLK may need an updated clock generator. Vivado synthesis and timing closure have not been run in this environment.

**Vivado:** In the Tcl console change directory to this extracted folder and `source create_project.tcl`. If modifying your existing project instead, replace RTL top, add `lab_vga.vhd`, remove old `vga_clock.vhd`/`vga_timing.vhd` from project, and replace XDC. Set top to `edge_detector_top`.
