library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library unisim;
use unisim.vcomponents.all;
entity edge_detector_top is
 port(
   clk12:in std_logic;
   btn_test:in std_logic;  -- hold for VGA color/edge test pattern
   cam_data:in std_logic_vector(7 downto 0);
   cam_href:in std_logic; cam_vsync:in std_logic; cam_pclk:in std_logic;
   cam_xclk:out std_logic; cam_sioc:out std_logic; cam_siod:inout std_logic;
   vga_r:out std_logic_vector(1 downto 0);
   vga_g:out std_logic_vector(1 downto 0);
   vga_b:out std_logic_vector(1 downto 0);
   vga_hsync:out std_logic; vga_vsync:out std_logic;
   led_ready:out std_logic; led_frame:out std_logic);
end;
architecture rtl of edge_detector_top is
 signal clk25, ready:std_logic;
 signal config_start_n : std_logic := '0';
 signal reset_count : natural range 0 to 120000 := 0;
 signal cam_valid,edge_valid,edge_bit:std_logic;
 signal cx:unsigned(8 downto 0);
 signal cy:unsigned(7 downto 0);
 signal gray:std_logic_vector(7 downto 0);
 signal waddr,raddr:unsigned(16 downto 0);
 signal rbit:std_logic;
 signal vx,vy:unsigned(9 downto 0);
 signal test_q:std_logic:='0';
 signal pixel_out:std_logic:='0';
 signal checker_q:std_logic:='0';

 signal test_sync1,test_sync2:std_logic:='0';
 signal vsync_old:std_logic:='0';
begin
 -- Internal 10 ms power-up delay before starting SCCB configuration.
 -- No FPGA GPIO is connected to the camera hardware RESET pin.
 process(clk12)
 begin
   if rising_edge(clk12) then
     if reset_count < 120000 then
       reset_count <= reset_count + 1;
       config_start_n <= '0';
     else
       config_start_n <= '1';
     end if;
   end if;
 end process;

 xclk_forward: ODDR generic map(DDR_CLK_EDGE=>"SAME_EDGE", INIT=>'0', SRTYPE=>"SYNC")
   port map(Q=>cam_xclk,C=>clk12,CE=>'1',D1=>'1',D2=>'0',R=>'0',S=>'0');
 cfg: entity work.sccb_init port map(clk=>clk12,reset_n=>config_start_n,sio_c=>cam_sioc,sio_d=>cam_siod,done=>ready);
 capture: entity work.camera_capture port map(
   pclk=>cam_pclk,enable=>ready,href=>cam_href,vsync=>cam_vsync,
   data=>cam_data,pix_valid=>cam_valid,pix_y=>gray,pix_x=>cx,pix_row=>cy);
 sobel: entity work.sobel_stream port map(
   clk=>cam_pclk,valid_in=>cam_valid,x_in=>cx,y_in=>cy,gray=>gray,
   wr_en=>edge_valid,wr_addr=>waddr,edge_out=>edge_bit);
 -- The timing/clock/blanking logic is taken from the original VGA lab.
 -- VGA lab RGB channels use 2 bits, and all VGA signals fit on JA.
 lab_display: entity work.lab_vga port map(
   clk=>clk12, pixel=>pixel_out, clk_pixel=>clk25,
   x=>vx, y=>vy, red=>vga_r, green=>vga_g, blue=>vga_b,
   hsync=>vga_hsync, vsync=>vga_vsync);
 raddr<=to_unsigned((to_integer(vy)/2)*320+(to_integer(vx)/2),17)
   when vx<640 and vy<480 else (others=>'0');
 fb: entity work.framebuffer port map(
   wclk=>cam_pclk,wen=>edge_valid,waddr=>waddr,wbit=>edge_bit,
   rclk=>clk25,raddr=>raddr,rbit=>rbit);
 -- Framebuffer data are read on the VGA clock. The lab's registered
 -- blank/sync signals correspond to the same pixel sampled for rbit.
 process(clk25)
 begin
   if rising_edge(clk25) then
     test_sync1<=btn_test;
     test_sync2<=test_sync1;
     test_q<=test_sync2;
     if ((to_integer(vx)/32 + to_integer(vy)/32) mod 2)=0 then
       checker_q<='1';
     else
       checker_q<='0';
     end if;
   end if;
 end process;
 pixel_out <= checker_q when test_q='1' else rbit;
 led_ready<=ready;
 process(cam_pclk)
 begin
   if rising_edge(cam_pclk) then
     vsync_old<=cam_vsync;
     if cam_vsync='1' and vsync_old='0' then led_frame<= '1';
     elsif cam_vsync='0' then led_frame<='0'; end if;
   end if;
 end process;
end;
