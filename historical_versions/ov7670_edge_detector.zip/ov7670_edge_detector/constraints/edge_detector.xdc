# Digilent Cmod A7 Rev B, XC7A35T-1CPG236C
# Source: https://github.com/Digilent/digilent-xdc/blob/master/Cmod-A7-Master.xdc
set_property -dict {PACKAGE_PIN L17 IOSTANDARD LVCMOS33} [get_ports clk12]
create_clock -name clk12 -period 83.333 [get_ports clk12]
set_property -dict {PACKAGE_PIN A18 IOSTANDARD LVCMOS33} [get_ports btn_test]
set_property -dict {PACKAGE_PIN A17 IOSTANDARD LVCMOS33} [get_ports led_ready]
set_property -dict {PACKAGE_PIN C16 IOSTANDARD LVCMOS33} [get_ports led_frame]

# OV7670, DIP GPIO numbers are printed as pio[01] etc. on Cmod board.
set_property -dict {PACKAGE_PIN M3 IOSTANDARD LVCMOS33} [get_ports {cam_data[0]}]  ;# DIP 1
set_property -dict {PACKAGE_PIN L3 IOSTANDARD LVCMOS33} [get_ports {cam_data[1]}]  ;# DIP 2
set_property -dict {PACKAGE_PIN A16 IOSTANDARD LVCMOS33} [get_ports {cam_data[2]}] ;# DIP 3
set_property -dict {PACKAGE_PIN K3 IOSTANDARD LVCMOS33} [get_ports {cam_data[3]}]  ;# DIP 4
set_property -dict {PACKAGE_PIN C15 IOSTANDARD LVCMOS33} [get_ports {cam_data[4]}] ;# DIP 5
set_property -dict {PACKAGE_PIN H1 IOSTANDARD LVCMOS33} [get_ports {cam_data[5]}]  ;# DIP 6
set_property -dict {PACKAGE_PIN A15 IOSTANDARD LVCMOS33} [get_ports {cam_data[6]}] ;# DIP 7
set_property -dict {PACKAGE_PIN B15 IOSTANDARD LVCMOS33} [get_ports {cam_data[7]}] ;# DIP 8
set_property -dict {PACKAGE_PIN A14 IOSTANDARD LVCMOS33} [get_ports cam_href]    ;# DIP 9
set_property -dict {PACKAGE_PIN J3 IOSTANDARD LVCMOS33} [get_ports cam_vsync]   ;# DIP 10
set_property -dict {PACKAGE_PIN J1 IOSTANDARD LVCMOS33} [get_ports cam_reset] ;# DIP 11 (camera RESET, active-low)
set_property -dict {PACKAGE_PIN N3 IOSTANDARD LVCMOS33} [get_ports cam_pclk]    ;# DIP 18 (clock capable)
set_property -dict {PACKAGE_PIN P3 IOSTANDARD LVCMOS33} [get_ports cam_xclk]    ;# DIP 19
set_property -dict {PACKAGE_PIN M2 IOSTANDARD LVCMOS33} [get_ports cam_sioc]    ;# DIP 20
set_property -dict {PACKAGE_PIN N1 IOSTANDARD LVCMOS33} [get_ports cam_siod]    ;# DIP 21
# Note: camera PCLK is asynchronous to VGA clock. Timing/CDC constraints must
# be reviewed after implementation. Do not blanket false-path the whole design.

# VGA Pmod J1 pins 1,2,3,4 = B0..B3; pins 7,8,9,10 = R0..R3.
# Connect J1 directly to Cmod JA with correct polarity and pin-1 orientation.
set_property -dict {PACKAGE_PIN G17 IOSTANDARD LVCMOS33} [get_ports {vga_b[0]}] ;# JA1
set_property -dict {PACKAGE_PIN G19 IOSTANDARD LVCMOS33} [get_ports {vga_b[1]}] ;# JA2
set_property -dict {PACKAGE_PIN N18 IOSTANDARD LVCMOS33} [get_ports {vga_b[2]}] ;# JA3
set_property -dict {PACKAGE_PIN L18 IOSTANDARD LVCMOS33} [get_ports {vga_b[3]}] ;# JA4
set_property -dict {PACKAGE_PIN H17 IOSTANDARD LVCMOS33} [get_ports {vga_r[0]}] ;# JA7
set_property -dict {PACKAGE_PIN H19 IOSTANDARD LVCMOS33} [get_ports {vga_r[1]}] ;# JA8
set_property -dict {PACKAGE_PIN J19 IOSTANDARD LVCMOS33} [get_ports {vga_r[2]}] ;# JA9
set_property -dict {PACKAGE_PIN K18 IOSTANDARD LVCMOS33} [get_ports {vga_r[3]}] ;# JA10

# VGA Pmod J2: G0..G3 and HS,VS -> additional DIP GPIO.
set_property -dict {PACKAGE_PIN R3 IOSTANDARD LVCMOS33} [get_ports {vga_g[0]}] ;# DIP 26 -> J2.1
set_property -dict {PACKAGE_PIN T3 IOSTANDARD LVCMOS33} [get_ports {vga_g[1]}] ;# DIP 27 -> J2.2
set_property -dict {PACKAGE_PIN R2 IOSTANDARD LVCMOS33} [get_ports {vga_g[2]}] ;# DIP 28 -> J2.3
set_property -dict {PACKAGE_PIN T1 IOSTANDARD LVCMOS33} [get_ports {vga_g[3]}] ;# DIP 29 -> J2.4
set_property -dict {PACKAGE_PIN T2 IOSTANDARD LVCMOS33} [get_ports vga_hsync] ;# DIP 30 -> J2.7
set_property -dict {PACKAGE_PIN U1 IOSTANDARD LVCMOS33} [get_ports vga_vsync] ;# DIP 31 -> J2.8
# Connect J2.5 or J2.11 to common GND and J2.6 or J2.12 to 3V3.
# J1 5/11 ground, 6/12 3V3 are provided by Cmod JA.
