library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library unisim;
use unisim.vcomponents.all;
entity edge_detector_top is
 port(
   clk12:in std_logic;
   btn_test:in std_logic;  -- hold for VGA color/edge test pattern
   cam_data:in std_logic_vector(7 downto 0);
   cam_href:in std_logic; cam_vsync:in std_logic; cam_pclk:in std_logic;
   cam_xclk:out std_logic; cam_reset:out std_logic; cam_sioc:out std_logic; cam_siod:inout std_logic;
   vga_r:out std_logic_vector(3 downto 0);
   vga_g:out std_logic_vector(3 downto 0);
   vga_b:out std_logic_vector(3 downto 0);
   vga_hsync:out std_logic; vga_vsync:out std_logic;
   led_ready:out std_logic; led_frame:out std_logic);
end;
architecture rtl of edge_detector_top is
 signal clk25, locked, ready:std_logic;
 signal cam_reset_n : std_logic := '0';
 signal reset_count : natural range 0 to 120000 := 0;
 signal cam_valid,edge_valid,edge_bit:std_logic;
 signal cx:unsigned(8 downto 0);
 signal cy:unsigned(7 downto 0);
 signal gray:std_logic_vector(7 downto 0);
 signal waddr,raddr:unsigned(16 downto 0);
 signal rbit:std_logic;
 signal vx,vy:unsigned(9 downto 0);
 signal vactive,hs,vs:std_logic;
 signal active_q,test_q:std_logic:='0';
 signal hs_q,vs_q:std_logic:='1';
 signal tx_q,ty_q:unsigned(9 downto 0):=(others=>'0');
 signal test_sync1,test_sync2:std_logic:='0';
 signal vsync_old:std_logic:='0';
begin
 -- OV7670 RESET is active-low on common modules. Hold in reset for
 -- 120,000 cycles of the 12 MHz oscillator (10 ms), then release.
 -- This is an FPGA logic-level output: verify the breakout accepts 3.3 V.
 cam_reset <= cam_reset_n;
 process(clk12)
 begin
   if rising_edge(clk12) then
     if reset_count < 120000 then
       reset_count <= reset_count + 1;
       cam_reset_n <= '0';
     else
       cam_reset_n <= '1';
     end if;
   end if;
 end process;
 clockgen: entity work.vga_clock port map(clk12=>clk12,clk25=>clk25,locked=>locked);
 xclk_forward: ODDR generic map(DDR_CLK_EDGE=>"SAME_EDGE", INIT=>'0', SRTYPE=>"SYNC")
   port map(Q=>cam_xclk,C=>clk12,CE=>'1',D1=>'1',D2=>'0',R=>'0',S=>'0');
 cfg: entity work.sccb_init port map(clk=>clk12,reset_n=>cam_reset_n,sio_c=>cam_sioc,sio_d=>cam_siod,done=>ready);
 capture: entity work.camera_capture port map(
   pclk=>cam_pclk,enable=>ready,href=>cam_href,vsync=>cam_vsync,
   data=>cam_data,pix_valid=>cam_valid,pix_y=>gray,pix_x=>cx,pix_row=>cy);
 sobel: entity work.sobel_stream port map(
   clk=>cam_pclk,valid_in=>cam_valid,x_in=>cx,y_in=>cy,gray=>gray,
   wr_en=>edge_valid,wr_addr=>waddr,edge_out=>edge_bit);
 timing: entity work.vga_timing port map(
   clk=>clk25,rst=>not locked,x=>vx,y=>vy,active=>vactive,hs=>hs,vs=>vs);
 raddr<=to_unsigned((to_integer(vy)/2)*320+(to_integer(vx)/2),17)
   when vactive='1' else (others=>'0');
 fb: entity work.framebuffer port map(
   wclk=>cam_pclk,wen=>edge_valid,waddr=>waddr,wbit=>edge_bit,
   rclk=>clk25,raddr=>raddr,rbit=>rbit);
 process(clk25)
 begin
  if rising_edge(clk25) then
    active_q<=vactive; hs_q<=hs; vs_q<=vs;
    tx_q<=vx; ty_q<=vy;
    test_sync1<=btn_test; test_sync2<=test_sync1; test_q<=test_sync2;
  end if;
 end process;
 -- Pixel read has one-cycle latency, matched by delayed active/sync/test.
 -- For test mode, display a checkerboard; otherwise display Sobel pixels.
 process(all)
 variable pixel:std_logic;
 begin
   if test_q='1' then
     if ((to_integer(tx_q)/32 + to_integer(ty_q)/32) mod 2)=0 then pixel:='1';
     else pixel:='0'; end if;
   else pixel:=rbit; end if;
   if active_q='1' then
     vga_r<=(others=>pixel); vga_g<=(others=>pixel); vga_b<=(others=>pixel);
   else
     vga_r<=(others=>'0'); vga_g<=(others=>'0'); vga_b<=(others=>'0');
   end if;
 end process;
 vga_hsync<=hs_q; vga_vsync<=vs_q;
 led_ready<=ready;
 process(cam_pclk)
 begin
   if rising_edge(cam_pclk) then
     vsync_old<=cam_vsync;
     if cam_vsync='1' and vsync_old='0' then led_frame<= '1';
     elsif cam_vsync='0' then led_frame<='0'; end if;
   end if;
 end process;
end;
