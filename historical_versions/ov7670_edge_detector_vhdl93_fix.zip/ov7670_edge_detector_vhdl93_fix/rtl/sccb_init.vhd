library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity sccb_init is
 port(clk:in std_logic; reset_n:in std_logic; sio_c:out std_logic; sio_d:inout std_logic; done:out std_logic);
end;
architecture rtl of sccb_init is
 type reg_pair is array(0 to 1) of std_logic_vector(7 downto 0);
 type rom_t is array(natural range <>) of reg_pair;
 constant init_rom:rom_t := (
 (x"12",x"80"), -- sensor reset
 (x"11",x"01"), -- clock prescaler
 (x"12",x"10"), -- QVGA, YUV
 (x"0C",x"04"), -- COM3 scaling enable
 (x"3E",x"19"), -- COM14 manual PCLK scaling
 (x"70",x"3A"), -- scaling X
 (x"71",x"35"), -- scaling Y
 (x"72",x"11"), -- 2x downsample
 (x"73",x"F1"), -- PCLK divisor
 (x"A2",x"02"), -- PCLK delay
 (x"3A",x"04"), -- YUYV byte sequence (with COM13)
 (x"3D",x"88"), -- COM13 (YUYV ordering)
 (x"40",x"C0"), -- full-range output
 (x"15",x"00"), -- normal VSYNC / PCLK
 (x"13",x"E7"), -- automatic gain/exposure/white balance
 (x"FF",x"FF")  -- end marker
 );
 type state_t is (BOOT, START_A, START_B, BIT_LOW, BIT_HIGH, ACK_LOW,
                  ACK_HIGH, STOP_LOW, STOP_HIGH, STOP_RELEASE, NEXT_REG, FINISHED);
 signal state:state_t:=BOOT;
 signal divcount:integer range 0 to 59:=0;
 signal bootcount:integer range 0 to 250000:=0;
 signal entry:integer range 0 to init_rom'length-1:=0;
 signal byte_idx:integer range 0 to 2:=0;
 signal bit_idx:integer range 0 to 7:=7;
 signal word8:std_logic_vector(7 downto 0):=(others=>'0');
 signal scl_low,sda_low:std_logic:='0';
begin
 sio_c<='0' when scl_low='1' else 'Z';
 sio_d<='0' when sda_low='1' else 'Z';
 done<='1' when state=FINISHED else '0';
 process(clk)
 begin
 if rising_edge(clk) then
   if reset_n='0' then
     state<=BOOT;
     divcount<=0;
     bootcount<=0;
     entry<=0;
     byte_idx<=0;
     bit_idx<=7;
     word8<=(others=>'0');
     scl_low<='0';
     sda_low<='0';
   elsif divcount=59 then
     divcount<=0;
     case state is
       when BOOT =>
         if bootcount=250000 then
           state<=START_A; entry<=0; byte_idx<=0;
         else bootcount<=bootcount+1; end if;
       when START_A =>
         scl_low<='0'; sda_low<='1'; state<=START_B;
         word8<=x"42"; bit_idx<=7;
       when START_B => scl_low<='1'; state<=BIT_LOW;
       when BIT_LOW =>
         scl_low<='1';
         if word8(bit_idx)='0' then sda_low<='1'; else sda_low<='0'; end if;
         state<=BIT_HIGH;
       when BIT_HIGH =>
         scl_low<='0';
         if bit_idx=0 then state<=ACK_LOW;
         else bit_idx<=bit_idx-1; state<=BIT_LOW; end if;
       when ACK_LOW =>
         scl_low<='1'; sda_low<='0'; state<=ACK_HIGH;
       when ACK_HIGH =>
         scl_low<='0';
         if byte_idx=0 then
           word8<=init_rom(entry)(0); byte_idx<=1; bit_idx<=7; state<=BIT_LOW;
         elsif byte_idx=1 then
           word8<=init_rom(entry)(1); byte_idx<=2; bit_idx<=7; state<=BIT_LOW;
         else state<=STOP_LOW; end if;
       when STOP_LOW => scl_low<='1'; sda_low<='1'; state<=STOP_HIGH;
       when STOP_HIGH => scl_low<='0'; sda_low<='1'; state<=STOP_RELEASE;
       when STOP_RELEASE => scl_low<='0'; sda_low<='0'; state<=NEXT_REG;
       when NEXT_REG =>
         if entry=init_rom'length-2 then state<=FINISHED;
         else entry<=entry+1; byte_idx<=0; state<=START_A; end if;
       when FINISHED => scl_low<='0'; sda_low<='0';
     end case;
   else divcount<=divcount+1; end if;
 end if;
 end process;
end;
