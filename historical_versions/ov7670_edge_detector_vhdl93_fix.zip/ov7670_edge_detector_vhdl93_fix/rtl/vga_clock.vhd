library ieee;
use ieee.std_logic_1164.all;
library unisim;
use unisim.vcomponents.all;

entity vga_clock is
  port(clk12 : in std_logic; clk25 : out std_logic; locked : out std_logic);
end entity;
architecture rtl of vga_clock is
  signal fb, fb_buf, clk_raw : std_logic;
begin
  -- 12 MHz * 63 / 30 = 25.2 MHz; MMCM VCO = 756 MHz.
  u_mmcm: MMCME2_BASE
    generic map(BANDWIDTH=>"OPTIMIZED", CLKIN1_PERIOD=>83.333,
      DIVCLK_DIVIDE=>1, CLKFBOUT_MULT_F=>63.0, CLKOUT0_DIVIDE_F=>30.0,
      CLKOUT0_PHASE=>0.0, CLKOUT0_DUTY_CYCLE=>0.5,
      STARTUP_WAIT=>FALSE)
    port map(CLKIN1=>clk12, CLKFBIN=>fb_buf, CLKFBOUT=>fb,
      CLKOUT0=>clk_raw, LOCKED=>locked, PWRDWN=>'0', RST=>'0');
  u_fb: BUFG port map(I=>fb, O=>fb_buf);
  u_out: BUFG port map(I=>clk_raw, O=>clk25);
end architecture;
