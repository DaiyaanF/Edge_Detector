library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity camera_capture is
  port(pclk:in std_logic; enable:in std_logic; href:in std_logic;
    vsync:in std_logic; data:in std_logic_vector(7 downto 0);
    pix_valid:out std_logic; pix_y:out std_logic_vector(7 downto 0);
    pix_x:out unsigned(8 downto 0); pix_row:out unsigned(7 downto 0));
end;
architecture rtl of camera_capture is
  signal href_old, vs_old : std_logic := '0';
  signal phase : std_logic := '0';
  signal xx : integer range 0 to 320 := 0;
  signal yy : integer range 0 to 255 := 0;
begin
 process(pclk)
 begin
 if rising_edge(pclk) then
   href_old<=href; vs_old<=vsync;
   pix_valid<='0';
   if enable='0' or (vsync='1' and vs_old='0') then
     xx<=0; yy<=0; phase<='0';
   elsif href='0' then
     phase<='0'; xx<=0;
     if href_old='1' and yy<255 then yy<=yy+1; end if;
   elsif href='1' then
     if href_old='0' then phase<='0'; xx<=0; end if;
     -- TSLB=0x04, COM13=0x88 select Y,U,Y,V: Y on even bytes.
     if phase='0' and xx<320 and yy<240 and enable='1' then
       pix_y<=data; pix_x<=to_unsigned(xx,9);
       pix_row<=to_unsigned(yy,8); pix_valid<='1';
       xx<=xx+1;
     end if;
     phase<=not phase;
   end if;
 end if;
 end process;
end;
