library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity vga_timing is
 port(clk:in std_logic; rst:in std_logic;
      x:out unsigned(9 downto 0); y:out unsigned(9 downto 0);
      active:out std_logic; hs:out std_logic; vs:out std_logic);
end;
architecture rtl of vga_timing is
 signal h : integer range 0 to 799 := 0;
 signal v : integer range 0 to 524 := 0;
begin
 process(clk)
 begin
 if rising_edge(clk) then
   if rst='1' then h<=0; v<=0;
   elsif h=799 then
     h<=0;
     if v=524 then v<=0; else v<=v+1; end if;
   else h<=h+1;
   end if;
 end if;
 end process;
 x<=to_unsigned(h,10); y<=to_unsigned(v,10);
 active<='1' when h<640 and v<480 else '0';
 hs<='0' when h>=656 and h<752 else '1';
 vs<='0' when v>=490 and v<492 else '1';
end;
