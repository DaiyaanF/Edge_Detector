# OV7670 debug revision: VGA lab + raw-camera diagnostic

This version keeps the original course VGA timing (`rtl/lab_vga.vhd`), 2-bit RGB JA wiring, camera DIP assignments, and no camera RESET GPIO (DIP 11 unused).

## Important changes
- **LD1 (A17 / `led_ready`):** blinks about every 0.35 s while VSYNC edges keep arriving. Goes off approximately 0.5 s after the last detected frame.
- **LD2 (C16 / `led_frame`):** solid ON while valid Y-channel pixels arrive. Goes off approximately 0.5 s after the last detected pixel activity event.
- These LEDs **do not indicate successful SCCB acknowledgments or correct image data**. A stuck VSYNC signal will not keep LD1 blinking.
- **Normal VGA image:** raw camera luminance MSB, resulting in a 1-bit black/white camera view (no Sobel filtering by default).
- **Hold BTN0:** VGA checkerboard test, independent of camera.
- Once a recognizable raw camera image appears, change `constant SHOW_SOBEL : boolean := false;` to `true` in `rtl/edge_detector_top.vhd`, then rebuild the bitstream to display Sobel output instead.
- `sccb_init.vhd` still does not check ACK, so camera configuration needs electrical verification.

## What the diagnostic results mean
- **LD1 dark, LD2 dark:** no observed VSYNC transitions and no valid captured pixels; check camera power, XCLK, RESET/PWDN, PCLK, and SCCB configuration.
- **LD1 blinking, LD2 dark:** VSYNC is changing but active pixels are not being captured; check HREF, PCLK, YUV configuration, `ready` and wiring.
- **LD1 blinking, LD2 on, black screen:** camera timing and accepted pixels are present; check pixel data D0–D7, luminance byte order and framebuffer read/write alignment. A black view may also mean the MSB of grayscale pixels stays low; point camera at a bright area.
- **LD1 dark, LD2 on:** pixels are appearing without frame edge transitions; check VSYNC connection and signal polarity.

## Wiring
Camera: D0–D7 to DIP 1–8; HREF DIP 9; VSYNC DIP 10; PCLK DIP 18; XCLK DIP 19; SCL DIP 20; SDA DIP 21; GND DIP 25. DIP 11 is free; camera RESET must be externally held at its correct inactive level. Camera VCC requires a proper regulated source appropriate for the breakout, never a resistor divider or FPGA logic pin. PWDN must be inactive. Ensure SCCB I/O and XCLK voltage compatibility before connecting.

VGA: the course lab's JA Pmod connector, using the exact `constraints/edge_detector.xdc` mapping. Do not use the previous 4-bit VGA mapping.

## Build
From an extracted directory run `source create_project.tcl` in Vivado's Tcl console, or import all `rtl/*.vhd` and `constraints/edge_detector.xdc` into the existing project. Set top `edge_detector_top`, remove old duplicate top/VGA files, and regenerate bitstream. The file is compatible with VHDL-93-style explicit processes and does not use `process(all)`.

## Limits
This is a diagnostic source revision, not a Vivado-tested or hardware-validated bitstream. The one-bit framebuffer can still exhibit tearing across unrelated camera and VGA clocks; later revisions should use double buffering or proper frame synchronization. VGA works per the user's hardware test, but the camera may still need sensor-specific register tuning. No functionality is claimed until the user tests the rebuilt project.

---

# OV7670 camera edge detector + original EN.520.424 VGA lab

This revision adapts the **actual `lab_f.vhd` VGA code** (MMCM parameters, 800×525 counters, registered HSYNC/VSYNC and blanking) to read pixels from the edge-detector framebuffer. `rtl/lab_vga.vhd` is the adapted VGA lab code; the camera/Sobel modules are retained.

**Wiring:** VGA Pmod as wired in your successful class lab; all 8 FPGA output signals use JA. The VGA Pmod must be the same 2-bit/channel hardware from the lab; other 12-bit Pmod VGA boards will need a different adapter/pin map. **Camera GPIOs:** D0..D7 DIP1..8, HREF 9, VSYNC 10, PCLK 18, XCLK 19, SCL 20, SDA 21; RESET is NOT mapped to DIP 11. Camera ground to DIP25. Use a regulated breakout-compatible power supply, not FPGA GPIO.

**Test:** Keep camera disconnected at first. Build design, connect VGA as in lab, and hold BTN0 for the checkerboard. If this works, connect camera and inspect the LED indicators.

The output is 640×480 VGA at 25.2 MHz; camera content is 320×240 scaled 2×. The display is monochrome, so red, green, blue 2-bit channels are each driven to 00 or 11.

**Caution:** The original SCCB configuration/camera clock and the camera-to-VGA frame buffer remain unverified on physical hardware. A working VGA test image alone does not prove the OV7670 is configured successfully. A camera with output needing 24 MHz XCLK may need an updated clock generator. Vivado synthesis and timing closure have not been run in this environment.

**Vivado:** In the Tcl console change directory to this extracted folder and `source create_project.tcl`. If modifying your existing project instead, replace RTL top, add `lab_vga.vhd`, remove old `vga_clock.vhd`/`vga_timing.vhd` from project, and replace XDC. Set top to `edge_detector_top`.
