# OV7670 + Cmod A7-35T + Digilent VGA Pmod: Sobel edge detector

This is an **initial hardware implementation**, not a hardware-tested turnkey bitstream. VHDL-2008 required for `process(all)`. Camera configuration may need tuning for individual OV7670 modules. Use a VGA monitor that supports 640x480/60 Hz.

## Design
- OV7670 camera **without FIFO** using an 8-bit parallel camera bus on DIP GPIO.
- SCCB register write initialization at approximately 100 kHz, 7-bit slave address 0x21 (8-bit write ID 0x42).
- No camera RESET GPIO: DIP 11 is unused. The FPGA internally delays SCCB configuration by 10 ms after startup, followed by the SCCB module’s boot delay.
- 12 MHz onboard clock forwarded to camera as XCLK using ODDR; OV7670 PCLK clocks capture and Sobel.
- QVGA 320x240 YUV422, configured byte order Y,U,Y,V. Brightness (Y) is taken from every even byte while HREF is high.
- 3x3 Sobel, approximate magnitude |Gx|+|Gy|; threshold currently 140 (edit in `sobel_stream.vhd`). Edge bit stored at (x-1,y-1) when x>=2,y>=2. First and final borders are black after initialization.
- 320x240 1-bit frame RAM, written in camera clock domain and read in separate 25.2 MHz VGA domain. The image is doubled to 640x480. Because **single-buffered**, occasional frame tearing is possible.
- Hold **BTN0** to see a VGA checkerboard without needing a working camera. **LED0** lights after SCCB writes are finished (does **not** prove ACK or actual camera response). **LED1** reflects high VSYNC after a rising edge, and is not a latched frame counter.

## WARNING: Electrical and hardware checks
1. Verify your camera breakout's **actual supply and IO voltage**. OV7670 *sensor* pins are not inherently 3.3 V tolerant. If the breakout has no appropriate level translation and regulator, use proper level shifters/regulators. Do not connect 5 V Arduino logic to FPGA GPIO.
2. Every GPIO and camera must share GND. Camera SIOC and SIOD require external pull-up resistors to the *safe SCCB IO voltage* (e.g., 2.8 V on an unshifted 2.8 V sensor); SIOC/SIOD are open-drain outputs from the FPGA.
3. If the camera's SCCB logic is below 3.3 V but 3.3 V FPGA can correctly detect its pull-up HIGH, the FPGA open-drain outputs can work with suitable pull-ups. Verify VIH thresholds and do not force 3.3 V onto a lower-voltage camera input.
4. Camera XCLK from this design is **3.3 V LVCMOS**; if the sensor XCLK is not 3.3 V tolerant you must level-shift XCLK (and possibly other IO). **Do not connect directly until this is checked.**
5. Camera RESET is **not** connected to any FPGA GPIO. Wire the breakout RESET to its proper **inactive logic level** for its sensor revision and IO supply; for common active-low reset devices this is HIGH at the camera’s safe IO voltage, not automatically 3.3 V. Tie PWDN to safe logic LOW. FIFO camera boards are not supported.
6. Pmod VGA J1 uses Cmod JA; J2 is wired with jumper leads to DIP GPIO. J2 also needs 3.3V power and GND.
7. Camera PCLK runs asynchronously to VGA 25.2 MHz; asynchronous dual-clock RAM provides image data crossing. The test-mode button is synchronized. Camera ready signal is stable long before capture; nevertheless, review CDC and post-route timing with Vivado.

## Camera DIP pin wiring (pin numbers as Digilent `pio` labels)
|Camera|Cmod DIP GPIO|FPGA package pin|
|---|---:|---|
|D0|1|M3|
|D1|2|L3|
|D2|3|A16|
|D3|4|K3|
|D4|5|C15|
|D5|6|H1|
|D6|7|A15|
|D7|8|B15|
|HREF|9|A14|
|VSYNC|10|J3|
|PCLK|18|N3|
|XCLK|19|P3|
|SIOC|20|M2|
|SIOD|21|N1|

## VGA Pmod wiring
Pmod VGA J1 (pins 1..4 = B0..B3, pins 7..10 = R0..R3) plugs into Cmod JA with matched pin-1 orientation:

|VGA J1|Cmod JA|FPGA pin|
|---|---|---|
|1 B0|1|G17|
|2 B1|2|G19|
|3 B2|3|N18|
|4 B3|4|L18|
|7 R0|7|H17|
|8 R1|8|H19|
|9 R2|9|J19|
|10 R3|10|K18|

VGA Pmod J2 **MUST** be connected with individual jumper wires:

|VGA J2|Cmod DIP GPIO|FPGA package pin|
|---|---:|---|
|1 G0|26|R3|
|2 G1|27|T3|
|3 G2|28|R2|
|4 G3|29|T1|
|7 HS|30|T2|
|8 VS|31|U1|
|5 or 11 GND|GND|--|
|6 or 12 VCC|3V3|--|

Verify J1 and J2 silk screen pin-1 placement before powering up. Two VGA Pmod J2 3V3 pins are common on the module, as are GND pins.

## Vivado
1. Open a Vivado Tcl console in the project directory and run `source create_project.tcl`, or use `vivado -mode batch -source create_project.tcl`.
2. Open generated project, confirm top `edge_detector_top`, VHDL-2008, XDC included.
3. Run **Synthesis**, inspect utilization and especially inferred framebuffer RAM. Run **Implementation** and inspect timing reports. Resolve all DRC/errors before programming.
4. Attach VGA monitor, initially keep camera disconnected/disabled, hold BTN0 to verify the checkerboard test pattern.
5. Safely wire the camera with RESET held at its inactive level from a compatible power rail (not GPIO 11), then release BTN0. LED0 lights after the SCCB sequence is transmitted.
6. If image is blank, inspect XCLK/PCLK/HREF/VSYNC and SCCB lines using a scope/logic analyzer; verify YUYV output and horizontal/vertical pixel counts. This SCCB engine does **not** inspect ACK, and `led_ready` only shows sequence completion.

## Basic simulation
A basic `sim/tb_sobel_stream.vhd` testbench feeds a horizontal black/white transition and checks that Sobel detects the center edge. In Vivado choose Run Simulation > Run Behavioral Simulation with `tb_sobel_stream` as simulation top. This bench has not been run in this environment.

## Limitations / engineering follow-ups
- The OV7670 sometimes needs a more complete initialization table including COM8, window-start/stop, exposure, and clock tweaks for a specific breakout. The included register list is a minimal QVGA starting point, **not guaranteed** for every module.
- The camera's PCLK is sampled with a clock-capable DIP pin. Add a `create_clock` and appropriate camera input timing constraints after measuring your PCLK and setup/hold margins on the real hardware; an exact constraint cannot be fabricated without measurement.
- The streaming Sobel implementation uses previous two rows and a 3-column shift register. It initializes the first frame's border to zero; the last row/column are not explicitly overwritten after start, but remain zero from initialization.
- This design uses a **single** edge-image framebuffer, not grayscale frame storage. Its 76,800 bits fit readily in A7-35T block RAM.
- No camera sensor identification/readback or per-transaction ACK checking yet; those would improve reliability.
- For production operation, add SCCB ACK/readback, timed retries, CDC review, double-buffering and a pixel-data pipeline simulation. A hardware reset GPIO is not implemented; RESET must be held inactive externally.

## References
- Digilent Cmod A7 master XDC: https://github.com/Digilent/digilent-xdc/blob/master/Cmod-A7-Master.xdc
- Cmod A7 reference manual: https://digilent.com/reference/_media/reference/programmable-logic/cmod-a7/cmod_a7_rm.pdf
- Pmod VGA schematic: https://digilent.com/reference/_media/reference/pmod/pmodvga/pmodvga_sch.pdf
- OV7670 register description: https://www.openhacks.com/uploadsproductos/ov7670_full_v1.3.pdf

## Change: removed camera RESET GPIO
- DIP pin 11 / FPGA package J1 is available and has no XDC assignment.
- Top-level `cam_reset` port and FPGA reset output were removed.
- `config_start_n` is an internal 10 ms startup gate, not a camera reset signal.
